import MG2D.*;
import MG2D.geometrie.*;   



class Main{

    public static void main(String[] args) {
        int vitesse = 4;
        Fenetre f = new Fenetre("MonAppli", 800, 600);
        Clavier clavier = f.getClavier();
        Souris souris = f.getSouris();

        //Création de la bagnole

        Rectangle corps_r2 = new Rectangle(Couleur.GRIS, new Point(150, 145), new Point(250,185), true);
        f.ajouter(corps_r2);
        Rectangle corps_r1 = new Rectangle(Couleur.GRIS_FONCE, new Point(50, 100), new Point(350, 145), true);
        f.ajouter(corps_r1);
        Cercle c1 = new Cercle(Couleur.NOIR, new Point(100,100), 20, true);
        Cercle c2 = new Cercle(Couleur.NOIR, new Point(300,100), 20, true);
        f.ajouter(c1);
        f.ajouter(c2);
        Triangle derriere_t1 = new Triangle(Couleur.GRIS_CLAIR, new Point(50, 145), new Point(150,145), new Point(150, 185), true);
        f.ajouter(derriere_t1);
        Triangle devant_t2 = new Triangle(Couleur.GRIS_CLAIR, new Point(250, 145), new Point(300, 145), new Point(250, 185), true);
        f.ajouter(devant_t2);
        
        //Boucle de fonctionnement du mouvement

        while(true){
            try{
                Thread.sleep(40);
            }
            catch(Exception e){}

            //Création du levier de vitesse

            if(clavier.getHautEnfoncee()){
                vitesse++;
            }

            if(clavier.getBasEnfoncee()){
                vitesse--;
            }

            //Création du mouvement Gauche/Droite

            if(clavier.getDroiteEnfoncee()){
                c1.translater(vitesse, 0);
                c2.translater(vitesse, 0);
                corps_r2.translater(vitesse, 0);
                corps_r1.translater(vitesse, 0);
                derriere_t1.translater(vitesse, 0);
                devant_t2.translater(vitesse, 0);
            }

            if(clavier.getGaucheEnfoncee()){
                c1.translater(-vitesse, 0);
                c2.translater(-vitesse, 0);
                corps_r2.translater(-vitesse, 0);
                corps_r1.translater(-vitesse, 0);
                derriere_t1.translater(-vitesse, 0);
                devant_t2.translater(-vitesse, 0);
            }

            //Retour au départ ou à la fin ;)
            
            if(corps_r1.getA().getX() >= 800){
                c1.translater(-1200, 0);
                c2.translater(-1200, 0);
                corps_r2.translater(-1200, 0);
                corps_r1.translater(-1200, 0);
                derriere_t1.translater(-1200, 0);
                devant_t2.translater(-1200, 0);
            }

            if(corps_r1.getB().getX() <= 0){
                c1.translater(1200, 0);
                c2.translater(1200, 0);
                corps_r2.translater(1200, 0);
                corps_r1.translater(1200, 0);
                derriere_t1.translater(1200, 0);
                devant_t2.translater(1200, 0);
            }

            //Changement de la carosserie

            if(souris.getBoutonGaucheEnfonce()){
                corps_r1.setCouleur(Couleur.ROUGE);
                corps_r2.setCouleur(Couleur.ROUGE);
            }

            if(souris.getBoutonDroitEnfonce()){
                corps_r1.setCouleur(Couleur.GRIS_FONCE);
                corps_r2.setCouleur(Couleur.GRIS);
            }

            //Rafraichissement de l'écran
            f.rafraichir();
        }
        
    }

    







}