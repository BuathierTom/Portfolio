#On importe les fonctions du dossier date.
from date import *


#Définition du dictionnaire

calendrier = []

#Ajout des évènements

ajoute_calendrier(calendrier, cree_date(1, 1, 2022), "Jour de l'an")
ajoute_calendrier(calendrier, cree_date(1, 5, 2022), "Fête du travail")
ajoute_calendrier(calendrier, cree_date(8, 5, 2022), "Armistice 1945")
ajoute_calendrier(calendrier, cree_date(14, 7, 2022), "Fête nationale")
ajoute_calendrier(calendrier, cree_date(15, 8, 2022), "Assomption")
ajoute_calendrier(calendrier, cree_date(25, 12, 2022), "Noel")

#Affichage

affiche_calendrier(calendrier)