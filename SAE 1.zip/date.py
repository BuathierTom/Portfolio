#%%
# Implémentation des dates et calendriers
# Implémentation des tests (voir main en fin de fichier)

from typing import Dict, List, Tuple, NoReturn


# =============================================================================
def est_bissextile(annee: int):
    """
    La fonction fait un calcul selon l'année pour savoir si elle est bissextile ou si elle ne l'est pas.
    Retourne Vrai ou Faux.

    Args:
        annee (int): Année donné par l'utilisateur 

    Returns:
        bool: True si l'année est bissextile et False si l'année ne l'est pas
        
    Tests:

    >>> est_bissextile(2020)
    True
    >>> est_bissextile(2021)
    False
    >>> est_bissextile(2022)
    False
    >>> est_bissextile(1900)
    False
    >>> est_bissextile(2000)
    True
    """    
    if (annee % 4 == 0) and (annee % 100 != 0) or (annee % 400 == 0): 
        #Calcul de l'année bissextile
        
        return True
    else:
        return False

    
# =============================================================================
def cree_date(jour: int, mois: int, annee: int):
    """
    Crée une date à partir des entiers la décrivant.
    Si l'un des paramètres n'est pas un entier, la fonction retournera None

    Args:
        jour (int): Jour de la date donnée par l'utilisateur
        mois (int): Mois donné par l'utilisateur 
        annee (int): Mois donné par l'utilisateur

    Returns:
        Dict: Retourne les entiers entrés par l'utilisateur dans un dictionnaire avec une description de la date. Si l'un des paramètres n'est pas entier 
              la fonction retourne None
        
    Tests:
    
    >>> cree_date(15,12,2020)
    {'jour': 15, 'mois': 12, 'annee': 2020}
    
    >>> cree_date(1.5,12,2020)
    
    """
    if type(jour) == int and type(mois) == int and type(annee) == int:
        #Permet de voir si les nombres rentrés sont bien des entiers
        
        date_dico = {'jour': jour , 'mois': mois, 'annee': annee}
        #Mise en place du dictionnaire date_dico
        
        return date_dico
    else:
        return None
        

# =============================================================================
def copie_date(date: Dict):
    """
    Copie la date passée en paramètre

    Args:
        date (Dict): Date donné en paramètre pour etre copier

    Returns:
        Dict: Date copier
        
    Tests:
    
    >>> copie_date({'jour': 19, 'mois': 10, 'annee': 2015})
    {'jour': 19, 'mois': 10, 'annee': 2015}
    """
    date_copie = {'jour': date['jour'],'mois': date['mois'],'annee': date['annee']}
    
    return date_copie

    
# =============================================================================
def compare(d1: Dict, d2: Dict):
    """
    Permet de classer deux dates.
    on considère que les dates sont croissantes 
    dans l'ordre chronologique

    Args:
        d1 (Dict): Date numéro une qui à était créé avec la fonction cree_date()
        d2 (Dict): Date numéro deux qui à était créé avec la fonction cree_date()

    Returns:
        [type]: Retourne -1 si la date d1 < d2 / +1 si la date d1 > d2 et 0 si les dates sont identiques
    
    Tests:
    
    >>> date1 = cree_date(15,11,2021)
    >>> date2 = cree_date(10,12,2021)
    >>> compare(date1,date2)
    -1
    >>> compare(date2,date1)
    1
    >>> compare(date1,date1)
    0
    """
    if d1['annee'] > d2['annee']: #On vérifie bien les années avant car si elle est plus petite ou plus grande le progamme se fini.
        return -1
    elif d1['annee'] < d2['annee']: 
        return -1
    elif d1['annee'] == d2['annee']:
        
        if d1['mois'] > d2['mois']: #La même chose avec les mois si les années sont les mêmes
            return 1
        elif d1['mois'] < d2['mois']:
            return -1
        elif d1['mois'] == d2['mois']:
            
            if d1['jour'] > d2['jour']: #Et si les mois sont identiques alors on diférencies les dates par leurs jours
                return -1
            elif d1['jour'] < d2['jour']:
                return 1
            elif d1['jour'] == d2['jour']:
                return 0
        return 0
    return 0


# =============================================================================
def valide_simple(date: Dict):
    """
    Fonction qui vérifie si la date est valide avec ces critères :
        - Si le premier (le jour) est un entier compris entre 1 et 31.
        - Si le second (le mois) est un entier compris entre 1 et 12.

    Args:
        date (Dict): Date à vérifier.

    Returns:
        bool: Retourne True si la date est valide et False si elle ne l'est pas.
        
    Tests:
    
    >>> date = cree_date(1, 2, 0)
    >>> valide_simple(date)
    True
    
    >>> date = cree_date(1.5, 5, 6)
    >>> valide_simple(date)
    False
    
    >>> date = cree_date(0, 5, 6)
    >>> valide_simple(date)
    False
    
    >>> date = cree_date(20, 8, 2021)
    >>> valide_simple(date)
    True
    """
    if date != None:
        if date['jour'] >= 1 and date['jour'] <= 31: #On regarde si les jours ne sont pas en desous de 1 ou au dessus de 31 jours
            if date['mois'] <= 12 and date['mois'] >= 1:#La même chose avec les mois
                return True
            else:
                return False
        else:
            return False
    else:
        return False
    

# =============================================================================
def valide_complet(date: Dict):
    """
    Retourne vrai si la date est valide. 
    On suppose que la date est valide si :
                - La validation simple est vraie
                - Si la date représente une date réelle 

    Args:
        date (Dict): Date à vérifier.

    Returns:
        bool: Renvoie True si la fonction valide_simple renvoie True et si la date est réelle dans un calendrier. Et renvoie False si la date n'est pas réelle ou si 
              la valide_simple retourne False
        
    Tests:
    
    >>> date = cree_date(15, 1, 2022)
    >>> valide_complet(date)
    True
    >>> date = cree_date(32, 1, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(-1, 1, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(31, 6, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(29, 2, 2020)
    >>> valide_complet(date)
    True
    >>> date = cree_date(29, 2, 2022)
    >>> valide_complet(date)
    False
    """
    resultat: bool
    mois_31 = [1, 3, 5, 7, 8, 10, 12]
    mois_30 = [4, 6, 9, 11]
    annee_biss = est_bissextile(date['annee'])
    if date['mois'] == 2:
        if annee_biss == True:
            if date['jour'] > 29:
                resultat = False
            else:
                resultat = True
        if annee_biss == False:
            if date['jour'] > 28:
                resultat = False
            else:
                resultat = True
    if date['mois'] in mois_31:
        if date['jour'] >= 1 and date['jour'] <= 31:
            resultat = True
        else:
            resultat = False
    if date['mois'] in mois_30:
        if date['jour'] >= 1 and date['jour'] <= 30:
            resultat = True
        else:
            resultat = False
    return resultat
        
            
# =============================================================================

calendrier = [] #Initialisation en dehors des fonctions car sinon la valeur serait écrasé.

def ajoute_calendrier(calendrier: List, date: Dict, description: str):
    """
    Ajoute un élément à la liste du calendrier.

    Args:
        calendrier (List): Calendrier a utilisé
        date (Dict): Date a utilisé pour la rajouté dans le calendrier
        description (str): Description de l'evenement de la date
    """
    if valide_complet(date):
        #On créer un élément description dans un dictionnaire
        desc = {'Description': description}
        #On l'ajoute au dictionnaire date
        date.update(desc)
        #On ajoute date à calendrier
        calendrier.append(date)
    else:
        print("La fonction n'est pas valide")
        
    
# =============================================================================
def affiche_calendrier(calendrier: List):
    """
    Affiche le calendrier sous forme de liste.

    Args:
        calendrier (List): Calendrier compléter
    """
    for i in range(len(calendrier)):
        print("Le {}/{}/{} : {}".format(calendrier[i]['jour'], calendrier[i]['mois'], calendrier[i]['annee'], calendrier[i]['Description']))
        i = i + 1


# =============================================================================


def ajoutes_fetes(calendrier: list, annee: int):
    """
    Fonction qui rajoutes des fêtes fixes

    Args:
        calendrier (list): Calendrier où l'on stocke les données
        annee (int): L'années des fêtes fixes que vous voulez rajouté dans calendrier
        
    Tests:
    
    #>>> ajoutes_fetes(calendrier, 2020)
    #Le 1/1/2020 : Jour de l'an
    #Le 25/12/2020 : Noël
    #Le 1/5/2020 : Fête du travail
    #Le 8/5/2020 : Victoire de 1945
    #Le 14/7/2020 : Fête Nationale
    #Le 15/8/2020 : Assomption
    #Le 1/11/2020 : Toussaint
    #Le 11/11/2020 : Armistice de 1918
    """
    #Ajoute les événements dans  le calendrier.
    
    ajoute_calendrier(calendrier, cree_date(1, 1, annee), "Jour de l'an")    
    ajoute_calendrier(calendrier, cree_date(25, 12, annee), "Noël")
    ajoute_calendrier(calendrier, cree_date(1, 5, annee), "Fête du travail")
    ajoute_calendrier(calendrier, cree_date(8, 5, annee), "Victoire de 1945")
    ajoute_calendrier(calendrier, cree_date(14, 7, annee), "Fête Nationale")
    ajoute_calendrier(calendrier, cree_date(15, 8, annee), "Assomption")
    ajoute_calendrier(calendrier, cree_date(1, 11, annee), "Toussaint")
    ajoute_calendrier(calendrier, cree_date(11, 11, annee), "Armistice de 1918")
    
    #Affichage des données : (A elenver si on ne veut pas de résultat retourner)
    #affiche_calendrier(calendrier)
    

# ============================================================================= 


def trouve_evenement(calendrier: list, date: dict):
    """
    Recherche le nom d'un evenement dont on connait la date et de retourner l'événement qui correspond. Si rien n'est trouvé alors la fonction retournera None

    Args:
        calendrier (list): Calendrier où il y a les dates et les descriptions des dates
        date (dict): La date donnée
        
    Returns:
        str: Retourne l'événement si la date en a un sinon elle retourne None 
    
    Tests:
    
    >>> trouve_evenement(calendrier, {'jour': 1, 'mois': 1, 'annee': 2015})
    "Jour de l'an"
    >>> trouve_evenement(calendrier, {'jour': 23, 'mois': 12, 'annee': 2015})
    
    """
    nveau_calendar = []
    if valide_complet(date) == True: #On vérifie la date si elle est valide ou pas
        ajoutes_fetes(calendrier, date['annee']) #On créé le calendrier général puis
        ajoutes_fetes(nveau_calendar, date['annee']) #le calendrier local
        
        for i in range(len(calendrier)): #On va chercher dans le calendrier la description
            if date['jour'] ==  nveau_calendar[i]['jour'] and date['mois'] == nveau_calendar[i]['mois']:
                return nveau_calendar[i]['Description']
                i = i + 1
            else:
                return None
    else:
        print("Date non valide")
    
    
    






if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
    
    
        #TESTS
    
    #print(est_bissextile(2020))
    #print(cree_date(15,12,2020))
    #print(cree_date(1.5,12,2020))
    #print(copie_date(15/12/2020))
    #copie_date({'jour': 19, 'mois': 10, 'annee': 2015})
    
    
    #date1 = cree_date(15,11,2021)
    #date2 = cree_date(10,12,2021)
    #print(compare(date1,date2)) 
    #print(compare(date2,date1))    
    #print(compare(date1,date1))
    
    #print(valide_simple({'jour': 19, 'mois': 10, 'annee': 2015}))
    
    #print(trouve_evenement(calendrier, {'jour': 1, 'mois': 1, 'annee': 2015}))

    

# %%
